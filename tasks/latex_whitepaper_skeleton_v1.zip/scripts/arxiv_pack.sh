#!/usr/bin/env bash
set -euo pipefail
OUTDIR="dist/arxiv"
mkdir -p "$OUTDIR"
# Copy sources
cp -v main.tex "$OUTDIR"/
cp -v .latexmkrc "$OUTDIR"/ || true
cp -vr sections "$OUTDIR"/
cp -vr includes "$OUTDIR"/
cp -vr figures "$OUTDIR"/
cp -vr bib "$OUTDIR"/
# Keep .bbl if present; arXiv can also run bibtex, but we include it for safety
if [ -f main.bbl ]; then cp -v main.bbl "$OUTDIR"/; fi
# Zip
cd dist && zip -r whitepaper_arxiv_source.zip arxiv
echo "Wrote dist/whitepaper_arxiv_source.zip"
