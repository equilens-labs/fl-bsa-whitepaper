# Claims to Substantiate (Final Draft)

- Dual-branch analysis quantifies amplification vs intrinsic fairness with signed evidence (cert chain valid).
- AIR ≥ 0.80 and EO gaps ≤ 0.05 for balanced/security/evidence_tamper scenarios in gold run; gender_bias scenario fails as expected for stress test.
- Distribution/QC fidelity: range violations eliminated; correlation/KS within thresholds per P2.5; privacy AUC improved (<0.89).
- No external egress; signed outputs; evidence bundle with manifest.
- Performance SLAs met on small synthetic runs; larger SLA evidence available in SSOT benchmarks.
