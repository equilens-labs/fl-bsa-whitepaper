# LaTeX White Paper — Publication-Ready (v1)

**Date:** 2025-10-13

This repository compiles a clean, regulator‑ready white paper to PDF (for your website) and an arXiv‑compatible source zip.
It **works with partial results**: if `intake/metrics_long.csv` is absent, the document still compiles with clear TBD markers.

## Structure
- `main.tex` — top‑level file
- `sections/` — logical sections (executive summary, estimands, methods, results, …)
- `includes/macros.tex` — global macros and thresholds
- `includes/metrics_macros.tex` — **auto‑generated** from metrics (safe default if missing)
- `scripts/gen_tex_macros_from_metrics.py` — reads `intake/metrics_long.csv` + `config/sap.yaml`, emits macros + tables
- `bib/references.bib` — BibTeX references
- `.github/workflows/latex.yml` — CI: builds PDF and arXiv source
- `Makefile` — local: `make pdf`, `make arxiv`, `make clean`

## Local build
```bash
# Optional: generate macros from metrics (tolerant to missing files)
python3 scripts/gen_tex_macros_from_metrics.py --metrics intake/metrics_long.csv --sap config/sap.yaml --outdir includes || true

# Build PDF
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
# Or: make pdf
```

## CI
On every PR/push:
- Generate macros (if `intake/` exists)
- Compile LaTeX to PDF (artifact: `main.pdf`)
- Package an **arXiv** source zip (artifact: `dist/whitepaper_arxiv_source.zip`)

## Partial results workflow
You can release a nearly complete paper and fill results later:
1. Commit this LaTeX project.
2. Add `intake/metrics_long.csv` and `config/sap.yaml` when ready.
3. Re-run CI — tables and thresholds auto‑populate; PDF and arXiv source update.
